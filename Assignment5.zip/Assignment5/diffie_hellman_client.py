#!/usr/bin/env python3
import socket
import argparse
import random
from pathlib import Path
from typing import Tuple

FILE_DIR: Path = Path(__file__).parent.resolve()
HOST: str = "localhost"

# TODO: Choose a P value that is shared with the server.
P: int = 23

def exchange_base_number(sock: socket.socket, server_port: int) -> int:
    # TODO: Connect to the server and propose a base number.
    # TODO: This should be a random number.
    proposal = random.randint(0, 100)
    sock.sendto(str(proposal).encode(), (HOST, server_port))
    print("Base proposal successful.")
    return proposal
 

def calculate_shared_secret(x: int, y: int, rx_int: int) -> int:
    # TODO: Calculate the shared secret and return it
    calculation = (rx_int ** y) % P
    return calculation


def generate_shared_secret(server_port: int) -> Tuple[int, int, int]:
    # TODO: Create a socket and send the proposed base number to the server.
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    x = exchange_base_number(client_socket, server_port)
    print("Base int is %s" % x)
    # TODO: Calculate the message the client sends using the secret integer.
    y = random.randint(0, 100)
    print("Y is %s" % y)
    send_to_server = (x ** y) % P;
    # TODO: Send it to the server.
    client_socket.sendto(str(send_to_server).encode(), (HOST, server_port))
    byteAddressPair = client_socket.recvfrom(1024)
    data = byteAddressPair[0]
    rx_int = int(data.decode())
    print("Int received from peer is %s" % rx_int)
    # TODO: Calculate the secret based on the server reply.
    secret = calculate_shared_secret(x, y, rx_int)
    print("Shared secret is %s" % secret)
    # TODO: Do not forget to close the socket.
    client_socket.close()
    # TODO: Return the base number, the private key, and the shared secret
    return x, y, secret


def main(args):
    if args.seed:
        random.seed(args.seed)
    generate_shared_secret(args.server_port)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "-s",
        "--server-port",
        default="8000",
        type=int,
        help="The port the client will connect to.",
    )
    parser.add_argument(
        "--seed",
        dest="seed",
        type=int,
        help="Random seed to make the exchange deterministic.",
    )
    # Parse options and process argv
    arguments = parser.parse_args()
    main(arguments)
