#!/usr/bin/env python3
from simulator import Simulator
from sliding_window_host import SlidingWindowHost

def return_congested_simulator(host):
    # TODO: Create simulator that shows a congestion collapse setting.
    # Use  0.0 for loss_ratio, 1000 for the seed, and 1000000 for queue_limit.
    simulator = Simulator(host, 0.0, 1000000, 10, 1000)
    return simulator


def tick_and_get_seq_number(window):
    host = SlidingWindowHost(window, verbose=False)
    simulator = return_congested_simulator(host)
    for tick in range(0, 10000):
        simulator.tick(tick)
    # Return the largest sequence number that has been received in order
    print(
        "Maximum in order received sequence number "
        + str(simulator.host.in_order_rx_seq)
    )
    return simulator.host.in_order_rx_seq


def get_window_sizes():
    # TODO: Select a progression of window sizes, which show a congestion collapse curve.
    window_sizes = []
    for num in range(1, 100):
        window_sizes.append(num)
    return window_sizes


def main():
    window_sizes = get_window_sizes()
    # Should have at least 10 entries.
    assert len(window_sizes) >= 10
    # Windows should be strictly increasing
    assert all(x <= y for x, y in zip(window_sizes, window_sizes[1:]))
    # TODO: For each window size, call tick_and_get_seq_number
    resList = []
    for window in window_sizes:
        res = tick_and_get_seq_number(window)
    # TODO: Collect the results
        resList.append(res)
    # Optional" Plot the results


if __name__ == "__main__":
    main()
