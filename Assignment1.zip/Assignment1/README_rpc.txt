Run the server first by typing:

python3 rpc_server.py 9001

Then run the client by typing:

python3 rpc_client.py 9001

You should see output like this if your solution is correct.

10-19-236-179:rpc tem373$ python3 rpc_client.py 9001
sent: prime(82)
prime: no

sent: prime(74)
prime: no

sent: prime(7)
prime: yes

sent: prime(97)
prime: yes

sent: prime(95)
prime: no

sent: prime(62)
prime: no

sent: prime(2)
prime: yes

sent: prime(94)
prime: no

sent: prime(26)
prime: no

sent: prime(46)
prime: no

10-19-236-179:rpc tem373$ python3 rpc_server.py 9001
 argument is 82
 argument is 74
 argument is 7
 argument is 97
 argument is 95
 argument is 62
 argument is 2
 argument is 94
 argument is 26
 argument is 46

