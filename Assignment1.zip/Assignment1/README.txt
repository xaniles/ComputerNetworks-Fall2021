This is the starter code for Assignment 1. There are three folders here,
corresponding to questions 8, 9, and 10. Each python file has several TODOs
that correspond to code fragments that you need to fill to complete the
assignment. We'll be using python3 for all questions. Each individual README
shows you how to run the completed code for each question and what the output
should look like.

You can run all programs on your local machine, i.e., localhost or 127.0.0.1,
but you're welcome to try them out on different physical machines if you have
access to 2 or more machines. Remember to close all open sockets at the end of
each program.  This is good form because it allows the operating system to
release resources for each socket so that they can be used by the next program.
